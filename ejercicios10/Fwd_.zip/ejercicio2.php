<?php

//2. Ejercicio de numeros pares: Escribe un programa que muestre todos los numeros pares del 1 al 100

for ($i = 2; $i <= 100; $i += 2) {
    echo $i . " ";
}
?>
